import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import javax.swing.border.LineBorder;

/**
 * for the grader, after this page app page you can press the back button at the very bottom to move back, its the back arrow at the bottom!!
 * 
 * @author Andrew Jaramillo and Kristiana Papagianni
 *
 */
public class ViewController extends JFrame implements Observer, ActionListener {
	
	private static final long serialVersionUID           = 2L; // needed by serializers
	private static final int  labelTickettArraySize      = 10; 
	private static final int  ticketTypeArraySize        = 6;
	private static final int  ComboArraySize            = 8;
	private static final int  centerTicketPanelArraySize = 4;
	private static final int  ticketTypeSize             = 50;
	private static final int  centerTicketPanelWidth     = 50;
	private static final int  centerTicketPanelHeigt     = 45;
	private PrintStream myOut = System.out;



	/*
	 *Here is the all the panels used in the app
	 *
	 */
	private Model theModel;

	private JPanel infoPanel;
	private JPanel mainPanel;
	private JPanel scrollPanel; 
	private JPanel widgetPanel;
	private JPanel totalTicket;
	private JPanel totalCombos;
	private JPanel scrollTheaterPanel;	

	
	private JScrollPane scroll;
	private JScrollPane scrollTheater;
	

	private JLabel paymentPanel;	
	private JLabel ShowDayTitle;
	private JLabel ShowTimeTitle;
	private JLabel adultTicketPanel;
	private JLabel childTicketPanel;
	private JLabel ticketTotalPanel;
	private JLabel seniorTicketPanel;
	private JLabel [] centerTicketPanel;
	private JLabel[] labelTickettArray;
	
	private JButton btnBack;
	private JButton theButton;
	private JButton appButton;
	private JButton timeButton;
	private JButton moveFoward;
	private JButton TicketTypeContinue;
	private JButton paymentContinue;
	
	private JButton[] ticketType;
	private JButton[] btnsMovieArray;
	private JButton[] btnsComboArray;
	

	private JTextField total;
	private JTextField ZipCode;	
	private JTextField cardNumber;
	private JTextField ExpireDate;
	private JTextField cardHolderName;
	private JTextField SecurityNumber;
	
	private Choice DayNames;	
	private Choice theaterNames;
	private Choice TimeNames;

	private JLabel comboWhiteLbl;
	private JLabel insideWhiteLbl;
	private JLabel redfirstLbl;
	private JLabel redsecondLbl;
	private JLabel redThirdLbl;
	private JLabel redFourLbl;
	
	private JLabel confirm;
	
	/**
	 * Creates the view-controller delegate
	 * 
	 * @param model
	 *            the Model
	 */
	public ViewController(Model model) {
		theModel = model;

		/*
		 * Set up some basic aspects of the frame
		 */
		Dimension thisScreen = Toolkit.getDefaultToolkit().getScreenSize();
		this.setSize(theModel.APP_WIDTH, theModel.APP_HEIGHT);
		this.setLocationByPlatform(true);
		this.setLocationRelativeTo(null);	
		this.getContentPane().setLayout(null);
		this.setTitle(this.getClass().getName());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/*
		 * Here we set up the GUI. 
		 * 
		 */
		//infoPanel = new JPanel();
		mainPanel          = new JPanel();
		widgetPanel        = new JPanel();
		totalTicket        = new JPanel();
		totalCombos        = new JPanel();
		paymentPanel       = new JLabel();
		ShowDayTitle       = new JLabel();
		adultTicketPanel   = new JLabel();		
		childTicketPanel   = new JLabel();
		seniorTicketPanel  = new JLabel();
		ticketTotalPanel   = new JLabel();
		ShowTimeTitle      = new JLabel();
		comboWhiteLbl      = new JLabel();
		insideWhiteLbl     = new JLabel();
		redfirstLbl        = new JLabel();
		redsecondLbl       = new JLabel();
		redThirdLbl        = new JLabel();
		redFourLbl         = new JLabel();
		confirm            = new JLabel();
		 
		// this is for the buttons with the arrows in the select ticket and the select combo. 
		centerTicketPanel  = new JLabel[centerTicketPanelArraySize];
		labelTickettArray  = new JLabel[labelTickettArraySize];
		
		// this is the text fields for isure input such as name, C.C and so on
		total              = new JTextField ();
		cardHolderName     = new JTextField ("(grading)add one random #");
		cardNumber         = new JTextField ("to all fields");
		ExpireDate         = new JTextField ();
		SecurityNumber     = new JTextField ();
		ZipCode            = new JTextField ();
		
		// all the buttons of the app
		timeButton         = new JButton();
		appButton          = new JButton();
		moveFoward         = new JButton();
		btnBack            = new JButton();
		moveFoward         = new JButton("continue");
		paymentContinue    = new JButton("Continue");	
		TicketTypeContinue = new JButton("Continue");	
		theButton          = new JButton("Press to Start");
		ticketType         = new JButton[theModel.getArrowtBtnImgArraySize()];
		btnsMovieArray     = new JButton[theModel.getNumberOfMovies()];
		
		// for the drop down menu 
		theaterNames       = new Choice();
		DayNames           = new Choice();
		TimeNames          = new Choice();
		

		//starting button
		theButton.setEnabled(true);
		ticketTotalPanel.setIcon( new ImageIcon(theModel.getTicketTotalJP()));
		// scroll panel for the movies
		scrollPanel = new JPanel(new GridLayout(0,3,10,10));
		
		// buttom part of the app that looks like the botton of a cell phone
		widgetPanel.setBackground(Color.WHITE);
		widgetPanel.setLayout(new BorderLayout());
		widgetPanel.add(theButton, BorderLayout.CENTER);
		widgetPanel.setSize(this.getWidth(),this.getHeight());
		widgetPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		//main panel will display all of the options to the user
		mainPanel.setSize(Model.MAIN_PANEL_WIDTH, Model.MAIN_PANEL_HEIGHT);
		mainPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		mainPanel.setBorder(new LineBorder( Color.RED, 5));
		

		// set the movies images 
		for(int i = 0; i < theModel.getNumberOfMovies(); i++) {
			ImageIcon image = new ImageIcon(theModel.getMovieImdAt(i));
			JButton tmp = new JButton();
			tmp.setIcon(image);
			tmp.setSize(Model.MOVIE_IMG_WIDTH, Model.MOVIE_IMG_HEIGHT);
			tmp.addActionListener(this);
			this.btnsMovieArray[i] = tmp;
		}
		// set the left and right  arrow buttons displayed in the choose ticket page and choose combo page
		for(int i = 0; i < theModel.getArrowtBtnImgArraySize()  ; i++) {
			ImageIcon image = new ImageIcon(theModel.getBtnImgAt(i));
			JButton tmpBtm = new JButton();
			tmpBtm.setIcon(image);
			ticketType[i] = tmpBtm;
			ticketType[i].setSize(ticketTypeSize,ticketTypeSize);
			ticketType[i].addActionListener(this);
		}
		// set the center panel that is in between the arrow buttons displayed in the choose ticket page and choose combo page
		for(int i = 0; i < centerTicketPanelArraySize; i++) {
			JLabel tmp = new JLabel(theModel.getTicketCt(i), JLabel.CENTER);
			tmp.setFont(new Font("Arial", Font.BOLD, 20));
			tmp.setBorder(new LineBorder( Color.BLACK, 1));
			tmp.setSize(centerTicketPanelWidth, centerTicketPanelHeigt);
			
			centerTicketPanel[i] = tmp;
		}

		
		// here we install this object (ActionListener) on the button so that we
		// may detect user actions that may be dispatched from it.

		
		
		btnBack.addActionListener(this);
		theButton.addActionListener(this);
		appButton.addActionListener(this);
		timeButton.addActionListener(this);
		moveFoward.addActionListener(this);
		paymentContinue.addActionListener(this);
		TicketTypeContinue.addActionListener(this);
		
		/*
		 * Here we install the view as a listener on the model. This way, when
		 * the model changes, the view will be notified and the view will know
		 * to redraw itself. This statement is presently commented out. We
		 * instead exposed this statement in the Runnable for pedagogical
		 * purposes.
		 */
		// model.addObserver(this);

		this.setVisible(true);

		// this method asks the frame layout manager to size the frame so that
		// all its contents are at or above their preferred sizes
		this.pack();
		// make this component visible (do not assume that it will be visible by
		// default)
		this.setVisible(true);
		this.getContentPane().add(mainPanel);
		this.getContentPane().add(widgetPanel);
	}

	@Override
	public Dimension getPreferredSize() {
		// find the dimensions of the screen and a dimension that is derive one
		// quarter of the size
		Dimension thisScreen = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension targetSize = new Dimension(Model.APP_WIDTH, Model.APP_HEIGHT);
		return targetSize;
	}

	@Override
	public void update(Observable o, Object arg) {
		// the model's state has updated

		if (theModel.getCurrentState() == Model.INIT_STATE) {
			// makes it appear as if we are about to open an app on a cell phone
			int appButtonSize     = 150, appButtonX      = 50,  appButtonY = 20,
				widgetPanelHeight = 70,  widgetPanelLocY = 710;
			
			mainPanel.removeAll();
			widgetPanel.remove(theButton);

			 JLabel tmp = new JLabel();
			 // get the image of the btm page and add it to the widgetPanel
			 tmp.setIcon(new ImageIcon(theModel.getPhnBtmImg()));
			 tmp.setSize(widgetPanel.getWidth(), widgetPanelHeight);
			 
			 //get the image of the app icon and add it to the button.
			 appButton.setIcon(new ImageIcon(theModel.getAppImg()));
			 appButton.setSize(appButtonSize,appButtonSize);
			 appButton.setLocation(appButtonX,appButtonY);
			 
			 mainPanel.add(appButton);
			 
			  
			 
			 
			 
			 // set the size of the widgetPanel
			 widgetPanel.setSize(this.getHeight(),widgetPanelHeight);
			 widgetPanel.setLocation(0, widgetPanelLocY);
			 widgetPanel.add(tmp);
			
			 mainPanel.repaint();

		} else if (theModel.getCurrentState() == Model.SELECT_MOVIE) {
			// the display for selecting a movie
			int theatersSelecHeight = 50;
			
			mainPanel.removeAll();
			//adds the movies to the buttons
			for(int i = 0; i < btnsMovieArray.length; i++) {
				scrollPanel.add(btnsMovieArray[i]);
			}
			
			// set movie scroll
			scroll = new JScrollPane(scrollPanel);
			scrollPanel.setSize(this.getWidth(),this.getHeight() );
			scroll.setSize(this.getWidth(), mainPanel.getHeight() - theatersSelecHeight);
			scroll.setLocation(0,theatersSelecHeight);

			// set the theater selection
			for(int i = 0; i <= theModel.getNumberOfTheaters(); i++) {
				JLabel tmp = new JLabel();
				if(i == 0) {
					theaterNames.add(theModel.getSelectTheaterStr());
				}else {
					theaterNames.add(theModel.getTheaterNameAt(i-1));
				}
			}

			
			theaterNames.setSize(this.getWidth(), theatersSelecHeight);
			btnBack.setBounds(20, 10,200, 50);
			
			// add the back button if the user wishes to go back
			widgetPanel.add(btnBack);
			mainPanel.remove(appButton);
			mainPanel.add(theaterNames);
			mainPanel.add(scroll);
			this.repaint();

		} else if (theModel.getCurrentState() == Model.SELECT_TIME) {


		
			mainPanel.removeAll();
			mainPanel.repaint();
				//this part is for the days choice
			for(int i = 0; i <= theModel.getNumberofWeekDays(); i++) {
					JLabel tmp = new JLabel();
					if(i == 0) {
						DayNames.add(theModel.getSelectDayStr());
					}else {
						DayNames.add(theModel.getWeekDaysNameAt(i-1));
					} }
					
			DayNames.setBounds(160, 430, 200, 50);
				add(TimeNames, BorderLayout.CENTER);
				mainPanel.add(DayNames);
				//this part is for the times choice
				for(int i = 0; i <= theModel.getNumberofTime(); i++) {
					JLabel tmp = new JLabel();
					if(i == 0) {
						TimeNames.add(theModel.getSelectTimeStr());
					}else {
						TimeNames.add(theModel.getTimeNameAt(i-1));
					} }
					
				// set the location of each panel and its settings 
				TimeNames.setBounds(160, 500, 200, 50);
				// the title 
				add(TimeNames, BorderLayout.CENTER);
				mainPanel.add(TimeNames);
				mainPanel.setBackground(Color.white);
				DayNames.setBackground(Color.white);
				TimeNames.setBackground(Color.white);
				
				// day display and selection
				ShowDayTitle.setBackground(Color.BLACK);
				ShowDayTitle.setFont(new Font("Tamil MN", Font.BOLD, 13));
				ShowDayTitle.setBounds(215, 399, 200, 50);
				ShowDayTitle.setText("Show Day");
				mainPanel.add(ShowDayTitle);
				
				// the show time diplay and selection 
				ShowTimeTitle.setBackground(Color.BLACK);
			    ShowTimeTitle.setFont(new Font("Tamil MN", Font.BOLD, 13));
			    ShowTimeTitle.setBounds(215, 470, 200, 50);
			    ShowTimeTitle.setText("Show Time");
			    mainPanel.add(ShowTimeTitle);
			    // continue button
			    timeButton.setBounds(160, 570, 200, 30);
			    timeButton.setBackground(Color.RED);
			    timeButton.setText("Continue");
			    timeButton.setFont(new Font("Tamil MN", Font.PLAIN, 13));
			    timeButton.setOpaque(true);
			    mainPanel.add(timeButton);
			    // selected image to be siplayed
			    JLabel ImageOfTitle = new JLabel();
			    ImageOfTitle.setText("Select Time");
			    ImageOfTitle.setFont(new Font("TIMES", Font.BOLD, 20));
			    ImageOfTitle.setBounds(200, 30, 200, 50);
			    ImageOfTitle.setBackground(Color.white);
			   
			   
			   
			    mainPanel.add(ImageOfTitle);
			   
				// add all the panels 
				JLabel ImagePanel=new JLabel();
				int location = theModel.getMovieSelectedIndex();
				ImagePanel.setIcon(new ImageIcon(theModel.getMovieImdAt(location)));
				ImagePanel.setBackground(Color.RED);
				ImagePanel.setBounds(180, 100, Model.MOVIE_IMG_WIDTH, Model.MOVIE_IMG_HEIGHT);
				mainPanel.add(ImagePanel);
				ImagePanel.setOpaque(true);
				
				
				 mainPanel.repaint();					
			
			
		
			//--------------------------------------------------------------------------------------------------------
	
		
		} else if (theModel.getCurrentState() == Model.SELECT_TICKET) {
			
			// for the select ticket type. adult,child,senior.
			//load all the images for child, adult, senior
			adultTicketPanel.setIcon(new ImageIcon(theModel.getAdultPanelImg()));
			childTicketPanel.setIcon( new ImageIcon(theModel.getChildPanelImg()));
			seniorTicketPanel.setIcon( new ImageIcon(theModel.getSniorPanelImg()));
			mainPanel.removeAll();
			totalTicket.removeAll();
			widgetPanel.add(btnBack);
			// set the size and locations 
			totalTicket.setBounds     	(52, 507, 447, 120);
			ticketTotalPanel.setBounds	(50, 400, 450, 150);
			adultTicketPanel.setBounds	(50, 30,200,150);
			childTicketPanel.setBounds	(335,30, 200,150);
			seniorTicketPanel.setBounds	(50,235,200,150);
			TicketTypeContinue.setBounds	(47, 635, 456, 30);
			
			
			totalTicket.setBackground(Color.WHITE);
			TicketTypeContinue.setBackground(Color.RED);
			TicketTypeContinue.setOpaque(true);
			
			//builds and positions all the left, center and right buttons----------------------
			int locX = 50, locY = 175, shitX = 185, shitY = 205,
				    btnWidth = ticketType[0].getWidth(),
					cntWidth = centerTicketPanel[0].getWidth();
			
			for(int i = 0; i < this.ticketTypeArraySize ; i++) {
				mainPanel.add(ticketType[i]);
				
				if(i % 2 == 0) {
					centerTicketPanel[(i%3)].setText(theModel.getTicketCt(i%3));
					
					mainPanel.add(centerTicketPanel[(i%3)]);
					ticketType[i].setLocation(locX, locY);
					centerTicketPanel[(i%3)].setLocation(locX + btnWidth, locY + 3);
					locX = locX + cntWidth + btnWidth;
				}else {
					ticketType[i].setLocation(locX, locY);
					locX = locX + shitX;
					if(i == 3) { 
						locX = 50; 
						locY = shitY + locY;
						
					}
						
					
					
				}
			}
			
			// builds and positions all of the totals and prices confirmation viewed at the bottom of the page 
			int X = 0;
			int Y = 0;
			for(int i = 0; i < 8; i++)
			{
				JLabel tmp;
				
				if(i % 2 == 0) {
					tmp = new JLabel("" ,JLabel.LEFT);
					tmp.setBounds(X, Y, 347, 30);
					X = X + 347;
				}else{
					tmp = new JLabel("" ,JLabel.RIGHT);
					tmp.setBounds(X, Y, 100, 30);
					Y = Y + 30;
					X = 0;
					}
				tmp.setBorder(new LineBorder( Color.BLACK, 1));
				if	   (i == 0) {tmp.setText(theModel.confirmationtAdultTxt());}
				else if(i == 1){tmp.setText(theModel. totalCostAdultTicket());}
				else if(i == 2) {tmp.setText(theModel.confirmationtChildTxt());}
				else if(i == 3) {tmp.setText(theModel.totalCostChildTicket());}
				else if(i == 4) {tmp.setText(theModel.confirmationtSeniorTxt() );}
				else if(i == 5) {tmp.setText(theModel.totalCostSeniorTicket());}
				else if(i == 6) {tmp.setText(theModel.TotalStr());}
				else            {tmp.setText(theModel.TotalTicketCostStr());}
				labelTickettArray[i] = tmp;
				totalTicket.add(tmp);		
			}
			// add all the panels to the MainPanel --------------

			mainPanel.add(adultTicketPanel);
			mainPanel.add(totalTicket);
			mainPanel.add(childTicketPanel);
			mainPanel.add(seniorTicketPanel);
			mainPanel.setBackground(Color.WHITE);
			mainPanel.add(ticketTotalPanel);
			mainPanel.add(TicketTypeContinue);

			mainPanel.repaint();
			
			
			
			
			
		} else if (theModel.getCurrentState() == Model.SELECT_COMBO) {
			// for selecting a combo
			mainPanel.removeAll();
			mainPanel.repaint();
			
			// totalCombos2 holds all of the images and buttons for select combo 
			JLabel totalCombos2 = new JLabel();
			totalCombos2.setBackground(Color.WHITE);
			totalCombos2.setBounds     (52, 520, 447, 120);
			
			// button to go to the next page
			moveFoward.setBounds(47, 635, 456, 30);
			moveFoward.setFont(new Font("Tamil MN", Font.BOLD, 13));
			moveFoward.setBackground(Color.RED);
			moveFoward.setOpaque(true);
			
			//outer panel
			comboWhiteLbl.setBackground(Color.WHITE);
			comboWhiteLbl.setBounds(190, 40, 150, 50);
			comboWhiteLbl.setFont(new Font("Tamil MN", Font.BOLD, 13));
			comboWhiteLbl.setBorder(new LineBorder( Color.RED, 4));
			//inner pannel
			comboWhiteLbl.setText(" Choose Food Combo");
			comboWhiteLbl.setOpaque(true);
			
			
			insideWhiteLbl.setBackground(Color.WHITE);
			insideWhiteLbl.setBounds(55, 100, 430, 400);
			insideWhiteLbl.setBorder(new LineBorder( Color.RED, 4));
			//
			insideWhiteLbl.setOpaque(true);
			// all the images
			insideWhiteLbl.add(redfirstLbl);
			insideWhiteLbl.add(redsecondLbl);
			insideWhiteLbl.add(redThirdLbl);
			insideWhiteLbl.add(redFourLbl);
			
			// the individual boxes that contain all the images and buttons 
			redfirstLbl.setBackground(Color.WHITE);
			redfirstLbl.setBounds(0, 0, 215, 200);
			redfirstLbl.setBorder(new LineBorder( Color.RED, 4));
			redfirstLbl.setOpaque(true);
			redfirstLbl.setVerticalAlignment(JLabel.TOP);
			redfirstLbl.setHorizontalAlignment(JLabel.CENTER);
	       
			redsecondLbl.setBackground(Color.WHITE);
			redsecondLbl.setBounds(215, 0, 215, 200);
			redsecondLbl.setBorder(new LineBorder( Color.RED, 4));
			redsecondLbl.setOpaque(true);
			redsecondLbl.setVerticalAlignment(JLabel.CENTER);
			redsecondLbl.setHorizontalAlignment(JLabel.CENTER);
			
			redThirdLbl.setBackground(Color.WHITE);
			redThirdLbl.setBounds(0, 200, 215, 200);
			redThirdLbl.setBorder(new LineBorder( Color.RED, 4));
			redThirdLbl.setOpaque(true);
			redThirdLbl.setVerticalAlignment(JLabel.CENTER);
			redThirdLbl.setHorizontalAlignment(JLabel.CENTER);
			
			redFourLbl.setBackground(Color.WHITE);
			redFourLbl.setBounds(215, 200, 215, 200);
			redFourLbl.setBorder(new LineBorder( Color.RED, 4));
			redFourLbl.setOpaque(true); 
			redFourLbl.setVerticalAlignment(JLabel.CENTER);
			redFourLbl.setHorizontalAlignment(JLabel.CENTER);
			
			//	adding all the images	
			redfirstLbl.setIcon(new ImageIcon(theModel.getCombo1PanelImg()));
			redsecondLbl.setIcon( new ImageIcon(theModel.getCombo2PanelImg()));
			redThirdLbl.setIcon( new ImageIcon(theModel.getCombo3PanelImg()));
			redFourLbl.setIcon( new ImageIcon(theModel.getCombo4PanelImg()));
			
			
			//builds and positions all the left, center and right buttons ---------------------------------
			int locX = 80, locY = 240, shitX = 120, shitY = 205, index = 0,
				    btnWidth = ticketType[0].getWidth(),
					cntWidth = centerTicketPanel[0].getWidth();
			
			
			for(int i = 0; i < this.ComboArraySize ; i++) {
				mainPanel.add(ticketType[i]);
				
				if(i % 2 == 0) {
					centerTicketPanel[index].setText(theModel.getComboCt(index));
					
					mainPanel.add(centerTicketPanel[index]);
					ticketType[i].setLocation(locX, locY);
					centerTicketPanel[index].setLocation(locX + btnWidth, locY + 3);
					locX = locX + cntWidth + btnWidth;
					index++;
				}else {
					ticketType[i].setLocation(locX, locY);
					locX = locX + shitX;
					if(i == 3) { 
						locX = 80; 
						locY = shitY + locY;
						
					}
						
					
					
				}
			}
			
			// builds and positions all of the totals and prices confirmation viewd at the bottom of the page 
			int X = 0;
			int Y = 0;
			for(int i = 0; i < 10; i++)
			{
				JLabel tmp;
				
				if(i % 2 == 0) {
					tmp = new JLabel("" ,JLabel.LEFT);
					tmp.setBounds(X, Y, 347, 30);
					X = X + 347;
				}else{
					tmp = new JLabel("" ,JLabel.RIGHT);
					tmp.setBounds(X, Y, 100, 30);
					Y = Y + 30;
					X = 0;
					}
				tmp.setBorder(new LineBorder( Color.BLACK, 1));
				if	   (i == 0) {tmp.setText(theModel.confirmationtcCombo1Txt());}
				else if(i == 1){tmp.setText(theModel. totalCostCombo1Ticket());}
				else if(i == 2) {tmp.setText(theModel.confirmationtCombo2Txt());}
				else if(i == 3) {tmp.setText(theModel.totalCostCombo2Ticket());}
				else if(i == 4) {tmp.setText(theModel.confirmationtCombo3Txt() );}
				else if(i == 5) {tmp.setText(theModel.totalCostCombo3Ticket());}
				else if(i == 6) {tmp.setText(theModel.confirmationtCombo4Txt() );}
				else if(i == 7) {tmp.setText(theModel.totalCostCombo4Ticket());}
				else if(i == 8) {tmp.setText(theModel.TotalStr());}
				else            {tmp.setText(theModel.TotalComboCostStr());}
				labelTickettArray[i] = tmp;
				totalCombos2.add(labelTickettArray[i]);		
			}
			
			mainPanel.add(insideWhiteLbl);
			mainPanel.add(comboWhiteLbl);
			mainPanel.add(moveFoward);
			mainPanel.add(totalCombos2);
				
		
			mainPanel.repaint();
			

			
		
	}else if (theModel.getCurrentState() == Model.PAYMENT) {
			
			// this is fgor the user to imput the C.C information 
			String BgColor = "#f1f1f1"; 
			mainPanel.removeAll();
			mainPanel.repaint();	
			mainPanel.setBackground(Color.WHITE);
			paymentPanel.setIcon(new ImageIcon(theModel.getPaymentImg()));
			// get the total value
			total.setText(theModel.getGrandTotalCost());
			
			// all the textFields for the user to input their information
			ExpireDate.setBackground(Color.decode    (BgColor)); 
			SecurityNumber.setBackground(Color.decode(BgColor)); 
			ZipCode.setBackground(Color.decode       (BgColor));
			cardNumber.setBackground(Color.decode    (BgColor)); 
			cardHolderName.setBackground(Color.decode(BgColor));
			paymentContinue.setBackground         (Color.RED );
			
			//set the size and location
			total.setBounds             (125, 150,  70, 20);
			paymentPanel.setBounds      ( 5,   0, 540, 600);
			cardHolderName.setBounds    (37, 258, 200, 25);
			cardNumber.setBounds        (37, 317, 200, 25);
			ExpireDate.setBounds        (37, 373,  65, 25);
			SecurityNumber.setBounds    (37, 428,  65, 25); 
			ZipCode.setBounds           (37, 525,  90, 25);	
			paymentContinue.setBounds   (47, 620, 456, 30);
			
			// make the textFields visible
			paymentContinue.setOpaque(true);
			SecurityNumber.setOpaque(true); 			
			cardHolderName.setOpaque(true);
			ExpireDate.setOpaque(true);
			cardNumber.setOpaque(true);
			ZipCode.setOpaque(true);
			
			// add everythign to the paymentPanel
			paymentPanel.add(total);
			paymentPanel.add(cardHolderName);
			paymentPanel.add(cardNumber);
			paymentPanel.add(ExpireDate);
			paymentPanel.add(SecurityNumber);
			paymentPanel.add(ZipCode);
			//add to main panel 
			mainPanel.add(paymentContinue);
			mainPanel.add(paymentPanel);
			widgetPanel.add(btnBack);
			
		}else if (theModel.getCurrentState() == Model.CONFIRMATION) {
			//last page this is for the confirmation
			mainPanel.removeAll();
			mainPanel.repaint();	
			mainPanel.setBackground(Color.WHITE);
			
			// to hold the summary values
			HashMap<String, String> transactionSum = theModel.getTransactionSummary();
			
			// top label that holds all the confiramtion values
			JLabel topConfirmationLabel = new JLabel();
			topConfirmationLabel.setBorder(new LineBorder( Color.RED, 4));
			topConfirmationLabel.setBounds(70, 50, 400, 300);
			topConfirmationLabel.setBackground(Color.WHITE);
			
			// image that has the bar code
			confirm.setBounds(70, 400, 430, 300);
			confirm.setIcon( new ImageIcon(theModel.getConfirm()));
			mainPanel.add(confirm);
			
			// for outputing the values in the confirmation page. Such as ticket type, combo and so on
			int X1 = 10, X2 = 190, Y = 5;
			int height = 30, width = 200;
			
			// movies selected
			JLabel movie = new JLabel("Movie",JLabel.LEFT);
			JLabel movieSelected = new JLabel(theModel.getMovieSelected(), JLabel.RIGHT);
	
			movie.setBounds        (X1, Y, width, height);
			movieSelected.setBounds(X2, Y, width, height);
			
			// for new values coming in, make them display below movie values
			Y = Y + height;
			
			// for values that where added through out the app 
			for(String key: transactionSum.keySet()) {
				
				JLabel tmp1 = new JLabel(key, JLabel.LEFT);
				JLabel tmp2 = new JLabel(transactionSum.get(key), JLabel.RIGHT);

				tmp1.setBounds(X1, Y, width,  height);
				tmp2.setBounds(X2, Y, width,  height);
				Y = Y +  height;
				
				topConfirmationLabel.add(tmp1);
				topConfirmationLabel.add(tmp2);
			}
			// this is for the total
			JLabel totalStr = new JLabel("Total",JLabel.LEFT);
			JLabel totalCost = new JLabel(theModel.getGrandTotalCost(), JLabel.RIGHT);
			totalStr.setOpaque(true);
			totalCost.setOpaque(true);

			totalStr.setBounds(X1, Y+30, width,  height);
			totalCost.setBounds(X2, Y+30, width,  height);
			
			// add all the panels to the topConfirmationLabel
			topConfirmationLabel.add(totalStr);
			topConfirmationLabel.add(totalCost);
			topConfirmationLabel.add(movieSelected);
			topConfirmationLabel.add(movie);
			
			topConfirmationLabel.repaint();
			//theModel.getTicketCt()
			mainPanel.add(topConfirmationLabel);
			mainPanel.repaint();	
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

			/*
			 * in response to button presses, we modify model attributes. We let
			 * this view's redraw of itself be delegated to when it is informed
			 * of the state change
			 */
			if (theModel.getCurrentState() == Model.STATE_UNASSIGNED) {
				
				//app has started move to the open app state
				theModel.setState(Model.INIT_STATE);
			
				
			} else if (theModel.getCurrentState() == Model.INIT_STATE) {
				
				// if back button is pressed
				if (e.getSource().equals(btnBack)) {
					theModel.setState( Model.INIT_STATE );
				// app button has been pressed 	
				}else {
					theModel.setState(Model.SELECT_MOVIE);
				}
				
				
				
				
				
			} else if (theModel.getCurrentState() == Model.SELECT_MOVIE) {
				
				// if back button is pressed
				if (e.getSource().equals(btnBack)) {
					//move back 
					theModel.setState(Model.INIT_STATE);
					
				}else if(theaterNames.getSelectedItem().equals(theModel.getSelectTheaterStr())) {
					theaterNames.setBackground(Color.RED);
				}else {
					//record the movie that was selected
					for(int i = 0; i < btnsMovieArray.length; i++) {
						if (e.getSource().equals(btnsMovieArray[i])){
							
							theModel.setMovieSelected(i);
							theModel.setState(Model.SELECT_TIME);
						}
					}
				}
				
				

				
			} else if(theModel.getCurrentState() == Model.SELECT_TIME ) {
				// if back button is pressed
				if (e.getSource().equals(btnBack)) {
					//move back 
					theModel.setState(Model.SELECT_MOVIE);
					
				}else {
					// user didn't input any fields 
					if(DayNames.getSelectedItem().equals(theModel.getSelectDayStr())) {
						DayNames.setBackground(Color.RED);
						theModel.setState(Model.SELECT_TIME);
					} else if(TimeNames.getSelectedItem().equals(theModel.getSelectTimeStr())) {
						TimeNames.setBackground(Color.RED);	
						theModel.setState(Model.SELECT_TIME);
					}else {
						// everthig was imputed correctly move on to the next stage
						theModel.setState(Model.SELECT_TICKET);
					}
					
				}
					
					
					
					
				
				
			} else if (theModel.getCurrentState() == Model.SELECT_TICKET) {
				if (e.getSource().equals(btnBack)) {
					// back button was pressed, move back 
					theModel.setState(Model.SELECT_TIME);
				}else if(e.getSource().equals(TicketTypeContinue)) {	
					// user  choose to move to the next state. confirm correvt input
					boolean notEmpty = false;
					for(int i = 0;i < 3;i++ ) {
						if(!theModel.getTicketCt(i).equals("0")) {
							notEmpty = true;
						}
					}
					if(notEmpty) {
						// everything is ok move to the next state
						theModel.setState(Model.SELECT_COMBO);
						
					}else {
						for(int i = 0; i < 3; i++) {
							//error highlight all fields red
							centerTicketPanel[i].setBorder(new LineBorder( Color.RED, 1));
							centerTicketPanel[i].setBackground(Color.RED);
							centerTicketPanel[i].setOpaque(true);
							
						}
						theModel.setState(Model.SELECT_TICKET);
					}
					
				}else{
					// check what button was pressed and update the correct fields
					for(int i = 0; i < ticketType.length; i++) {
						if (e.getSource().equals(ticketType[i])) {
							if(i % 2 == 0) {
								theModel.decreaseTicketCount(i%3);
						
								
								
							}else {
								theModel.increaseTicketCount((i - 1)%3);
								
							}
							
							theModel.setState(Model.SELECT_TICKET);
						}
						centerTicketPanel[i%3].setBackground(Color.WHITE);
						centerTicketPanel[i%3].setOpaque(true);
					}
				}	
				
			}
			else if(theModel.getCurrentState() == Model.SELECT_COMBO ) {
				

				if (e.getSource().equals(btnBack)) {
					// back button was pressed, move back 
					theModel.setState(Model.SELECT_TIME);
				}else if(e.getSource().equals(moveFoward)) {	
					boolean notEmpty = false;
					for(int i = 0;i < 3;i++ ) {
						if(!theModel.getComboCt(i).equals("0")) {
							notEmpty = true;
						}
					}
					if(notEmpty) {
						// everything is ok move to the next state
						theModel.setState(Model.PAYMENT);
						
					}else {
						for(int i = 0; i < 4; i++) {
							//error highlight all fields red
							centerTicketPanel[i].setBorder(new LineBorder( Color.RED, 1));
							centerTicketPanel[i].setBackground(Color.RED);
							centerTicketPanel[i].setOpaque(true);
							
						}
						// stay in same state
						theModel.setState(Model.SELECT_COMBO);
					}
					
				}else{
					// update correct fields 
					for(int i = 0; i < ticketType.length; i++) {
						if (e.getSource().equals(ticketType[i])) {
							
							if(i % 2 == 0) {
								theModel.decreaseComboCount((i + 1) / 2);
						
								
								
							}else {
								theModel.increaseComboCount((i/2));
								
							}
							
							theModel.setState(Model.SELECT_COMBO);
						}
						centerTicketPanel[i%4].setBackground(Color.WHITE);
						centerTicketPanel[i%4].setOpaque(true);
					}
				}
				
			}else if(theModel.getCurrentState() == Model.PAYMENT) {
				
				if(e.getSource().equals(btnBack)) {
					// back button was pressed, move back 
					theModel.setState(Model.SELECT_COMBO);
				}
				else if(e.getSource().equals(paymentContinue)){
					// user missed a field, highlight in red
					boolean isEmpty = false;

					if (cardHolderName.getText().isEmpty()) {
						isEmpty = true;
						cardHolderName.setBorder(new LineBorder( Color.RED, 2));
					}
					if (cardNumber.getText().isEmpty()) {
						isEmpty = true;
						cardNumber.setBorder(new LineBorder( Color.RED, 2));
					}
					if (ExpireDate.getText().isEmpty()) {
						isEmpty = true;
						ExpireDate.setBorder(new LineBorder( Color.RED, 2));
					}
					if (SecurityNumber.getText().isEmpty()) {
						isEmpty = true;
						SecurityNumber.setBorder(new LineBorder( Color.RED, 2));
					}
					if(ZipCode.getText().isEmpty()) {
						isEmpty = true;
						ZipCode.setBorder(new LineBorder( Color.RED, 2));
					}
					if(isEmpty) {
						theModel.setState(Model.PAYMENT);
					}else {
						theModel.setState(Model.CONFIRMATION);
					}

				}
					
					
			}

			// myOut.println("Button press");
		

	}

	/**
	 * Launch thread to wait and then enable button
	 * 
	 * @return
	 *//*
	private SwingWorker<Void, Void> createWorkerDelayedEnabledButton(int delayInMSec) {
		return new SwingWorker<Void, Void>() {
			@Override
			protected Void doInBackground() {
				try {
					Thread.sleep(delayInMSec);
				} catch (InterruptedException e) {
					myOut.println("Error Occurred.");
				}
				theButton.setEnabled(true);
				return null;
			}
		};
	}
*/
}